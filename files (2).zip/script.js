// Particle System
class ParticleSystem {
    constructor() {
        this.canvas = document.getElementById('particleCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.mouseX = 0;
        this.mouseY = 0;
        
        this.resizeCanvas();
        this.createParticles();
        this.animate();
        
        window.addEventListener('resize', () => this.resizeCanvas());
        document.addEventListener('mousemove', (e) => {
            this.mouseX = e.clientX;
            this.mouseY = e.clientY;
            this.createMouseParticles(e.clientX, e.clientY);
        });
    }
    
    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }
    
    createParticles() {
        for (let i = 0; i < 100; i++) {
            this.particles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                vx: (Math.random() - 0.5) * 2,
                vy: (Math.random() - 0.5) * 2,
                size: Math.random() * 3 + 1,
                color: ['#00FFFF', '#39FF14', '#FFFFFF'][Math.floor(Math.random() * 3)],
                opacity: Math.random() * 0.5 + 0.2,
                life: Math.random() * 100 + 50
            });
        }
    }
    
    createMouseParticles(x, y) {
        for (let i = 0; i < 5; i++) {
            this.particles.push({
                x: x + (Math.random() - 0.5) * 20,
                y: y + (Math.random() - 0.5) * 20,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                size: Math.random() * 2 + 1,
                color: '#00FFFF',
                opacity: 1,
                life: 30
            });
        }
    }
    
    animate() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.particles.forEach((particle, index) => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            particle.life--;
            particle.opacity -= 0.01;
            
            if (particle.life <= 0 || particle.opacity <= 0) {
                this.particles.splice(index, 1);
                return;
            }
            
            // Wrap around screen
            if (particle.x < 0) particle.x = this.canvas.width;
            if (particle.x > this.canvas.width) particle.x = 0;
            if (particle.y < 0) particle.y = this.canvas.height;
            if (particle.y > this.canvas.height) particle.y = 0;
            
            // Draw particle
            this.ctx.save();
            this.ctx.globalAlpha = particle.opacity;
            this.ctx.fillStyle = particle.color;
            this.ctx.shadowBlur = 10;
            this.ctx.shadowColor = particle.color;
            this.ctx.fillRect(particle.x, particle.y, particle.size, particle.size);
            this.ctx.restore();
        });
        
        // Maintain particle count
        while (this.particles.length < 100) {
            this.particles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                vx: (Math.random() - 0.5) * 2,
                vy: (Math.random() - 0.5) * 2,
                size: Math.random() * 3 + 1,
                color: ['#00FFFF', '#39FF14', '#FFFFFF'][Math.floor(Math.random() * 3)],
                opacity: Math.random() * 0.5 + 0.2,
                life: Math.random() * 100 + 50
            });
        }
        
        requestAnimationFrame(() => this.animate());
    }
}

// Custom Cursor
class CustomCursor {
    constructor() {
        this.cursor = document.createElement('div');
        this.cursor.className = 'mouse-trail';
        document.body.appendChild(this.cursor);
        
        document.addEventListener('mousemove', (e) => {
            this.cursor.style.left = e.clientX + 'px';
            this.cursor.style.top = e.clientY + 'px';
            this.cursor.style.opacity = '1';
        });
        
        document.addEventListener('mouseleave', () => {
            this.cursor.style.opacity = '0';
        });
    }
}

// Smooth Scrolling
class SmoothScroll {
    constructor() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }
}

// Scroll Reveal Animation
class ScrollReveal {
    constructor() {
        this.elements = document.querySelectorAll('.about-card, .project-card, .contact-item');
        this.observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        this.observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('scroll-reveal', 'revealed');
                }
            });
        }, this.observerOptions);
        
        this.elements.forEach(el => {
            el.classList.add('scroll-reveal');
            this.observer.observe(el);
        });
    }
}

// Typing Animation
class TypingAnimation {
    constructor(element, text, speed = 100) {
        this.element = element;
        this.text = text;
        this.speed = speed;
        this.index = 0;
        
        this.element.textContent = '';
        this.type();
    }
    
    type() {
        if (this.index < this.text.length) {
            this.element.textContent += this.text.charAt(this.index);
            this.index++;
            setTimeout(() => this.type(), this.speed);
        }
    }
}

// Form Handling
class FormHandler {
    constructor() {
        this.form = document.querySelector('.space-form');
        if (this.form) {
            this.form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleSubmit();
            });
        }
    }
    
    handleSubmit() {
        const formData = new FormData(this.form);
        
        // Simulate form submission
        const button = this.form.querySelector('button[type="submit"]');
        const originalText = button.textContent;
        
        button.textContent = 'Transmitting...';
        button.disabled = true;
        
        setTimeout(() => {
            button.textContent = 'Signal Sent!';
            setTimeout(() => {
                button.textContent = originalText;
                button.disabled = false;
                this.form.reset();
            }, 2000);
        }, 1500);
    }
}

// Audio Context for Space Sounds (Optional)
class SpaceSounds {
    constructor() {
        this.audioContext = null;
        this.initAudio();
    }
    
    initAudio() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        } catch (e) {
            console.log('Web Audio API not supported');
        }
    }
    
    playBeep(frequency = 440, duration = 200) {
        if (!this.audioContext) return;
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.1, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration / 1000);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + duration / 1000);
    }
}

// Interactive Elements
class InteractiveElements {
    constructor() {
        this.spaceSounds = new SpaceSounds();
        this.addHoverEffects();
        this.addClickEffects();
    }
    
    addHoverEffects() {
        document.querySelectorAll('.btn-primary, .btn-secondary, .nav-link').forEach(element => {
            element.addEventListener('mouseenter', () => {
                this.spaceSounds.playBeep(800, 100);
            });
        });
        
        document.querySelectorAll('.project-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                this.spaceSounds.playBeep(600, 150);
            });
        });
    }
    
    addClickEffects() {
        document.querySelectorAll('button, .nav-link').forEach(element => {
            element.addEventListener('click', () => {
                this.spaceSounds.playBeep(1000, 200);
                this.createClickRipple(element);
            });
        });
    }
    
    createClickRipple(element) {
        const ripple = document.createElement('div');
        ripple.style.cssText = `
            position: absolute;
            border-radius: 50%;
            background: rgba(0, 255, 255, 0.3);
            width: 20px;
            height: 20px;
            animation: ripple 0.6s ease-out;
            pointer-events: none;
            z-index: 1000;
        `;
        
        const rect = element.getBoundingClientRect();
        ripple.style.left = (rect.left + rect.width / 2 - 10) + 'px';
        ripple.style.top = (rect.top + rect.height / 2 - 10) + 'px';
        
        document.body.appendChild(ripple);
        
        setTimeout(() => {
            document.body.removeChild(ripple);
        }, 600);
    }
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add ripple keyframes to document
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Initialize all systems
    new ParticleSystem();
    new CustomCursor();
    new SmoothScroll();
    new ScrollReveal();
    new FormHandler();
    new InteractiveElements();
    
    // Initialize typing animation for hero title
    const heroTitle = document.querySelector('.typing-text');
    if (heroTitle) {
        const text = heroTitle.getAttribute('data-text');
        new TypingAnimation(heroTitle, text, 100);
    }
});

// Performance optimization
window.addEventListener('load', () => {
    // Lazy load animations
    setTimeout(() => {
        document.body.classList.add('loaded');
    }, 500);
});

// Add some extra visual effects
setInterval(() => {
    // Random pixel glitch effect
    if (Math.random() < 0.1) {
        const elements = document.querySelectorAll('.pixel-text');
        const randomElement = elements[Math.floor(Math.random() * elements.length)];
        if (randomElement) {
            randomElement.style.textShadow = '2px 0 #ff0000, -2px 0 #00ffff';
            setTimeout(() => {
                randomElement.style.textShadow = '';
            }, 100);
        }
    }
}, 2000);

// Easter egg: Konami code
let konamiCode = [];
const konamiSequence = [38, 38, 40, 40, 37, 39, 37, 39, 66, 65];

document.addEventListener('keydown', (e) => {
    konamiCode.push(e.keyCode);
    if (konamiCode.length > konamiSequence.length) {
        konamiCode.shift();
    }
    
    if (konamiCode.toString() === konamiSequence.toString()) {
        // Activate special mode
        document.body.style.filter = 'hue-rotate(180deg)';
        setTimeout(() => {
            document.body.style.filter = '';
        }, 5000);
    }
});